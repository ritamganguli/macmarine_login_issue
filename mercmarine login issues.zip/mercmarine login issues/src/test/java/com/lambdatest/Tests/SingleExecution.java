package com.lambdatest;
import java.lang.reflect.Method;
import java.net.MalformedURLException;
import java.net.URL;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
public class SingleExecution{
    private RemoteWebDriver driver;
    private String Status = "failed";
    @BeforeMethod
    public void setup(Method m, ITestContext ctx) throws MalformedURLException {
        String username = "ritamg";
        String authkey = "lHWNSA0QECwjeN8DoDb9U6KyXMBgAFXqlIIArkxeOTDSeEdLyG";
        ;
        String hub = "@hub-virginia.lambdatest.com/wd/hub";
        DesiredCapabilities caps = new DesiredCapabilities();
//        caps.setCapability("platform", "MacOS Monterey");
        caps.setCapability("platform", "MacOS Catalina");
        caps.setCapability("browserName", "Safari");
        caps.setCapability("version", "13.0");
        caps.setCapability("build", "Mercmarine scroll");
//        caps.setCapability("acceptInsecureCerts", true);
        caps.setCapability("extendedDebuging", true);
//        caps.setCapability("network", true);
        caps.setCapability("w3c", true);
        caps.setCapability("safari.cookies", true);
        caps.setCapability("name","Safari Issue");
        caps.setCapability("visual", true);
//        caps.setCapability("plugin", "git-testng");
        /*
        Enable Smart UI Project
        caps.setCapability("smartUI.project", "<Project Name>");
        */
        String[] Tags = new String[] { "Feature", "Magicleap", "Severe" };
        caps.setCapability("tags", Tags);
        driver = new RemoteWebDriver(new URL("https://" + username + ":" + authkey + hub), caps);
    }
    @Test
    public void basicTest() throws InterruptedException {
        String spanText;
        System.out.println("Loading Url");
        driver.get("https://Stg-reservations.freedomboatclub.com");
        Thread.sleep(1000);
//        System.out.println("Click I Accept button");
//        driver.findElement(By.xpath("//*[@id=\"onetrust-accept-btn-handler\"]")).click();
        System.out.println("Enter Email Id");
        driver.findElement(By.xpath("//*[@id=\"signInName\"]")).sendKeys("atstfbc+freedom6@gmail.com");
        Thread.sleep(1000);
        System.out.println("Enter Password");
        driver.findElement(By.xpath("//*[@id=\"password\"]")).sendKeys("Testfreedom@23");
//        //*[@id="mainMenuToggle"]
//        //*[@id="mainMenuToggle"]/div
//        mainMenuToggle
        Thread.sleep(10000);
        // Let's also assert that the todo we added is present in the list.
        System.out.println("Click Sign in");
        driver.findElement(By.xpath("//*[@id=\"next\"]")).click();
//        JavascriptExecutor js = (JavascriptExecutor) driver;
//        WebElement Element = driver.findElement(By.xpath("//*[@id=\"container-4220db2194\"]/div/div[2]/div[2]/a"));
//
//        // Scrolling up the page till the element is found
//        js.executeScript("arguments[0].scrollIntoView(true);", Element);
//
        Thread.sleep(15000);
        System.out.println("Click Reserve");
        driver.findElement(By.xpath("/html/body/div[1]/div/div/div[1]/div/div/div/div[2]/div[2]/a")).click();
        Thread.sleep(15000);
        //Scrolling up
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,-950)", "");
//        WebElement targetElement = driver.findElement(By.xpath("///*[@id=\"mainMenuToggle\"]")); // Replace with your element's locator
//        JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
//        jsExecutor.executeScript("arguments[0].scrollIntoView(true);", targetElement);
        Thread.sleep(25000);
        System.out.println("Click F6");
        driver.findElement(By.xpath("//*[@id=\"mainMenuToggle\"]/div")).click();
        System.out.println("Click Logout");
        driver.findElement(By.xpath("//*[@id=\"logout\"]")).click();
        Status = "passed";
        Thread.sleep(150);
        System.out.println("TestFinished");
    }
    @AfterMethod
    public void tearDown() {
        driver.executeScript("lambda-status=" + Status);
        driver.quit();
    }
}